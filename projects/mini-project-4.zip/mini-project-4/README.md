# FOCUS
![Preview](https://github.com/Sonnyyy77/abc-student-repo/blob/master/projects/mini-project-4/Demo.gif)

By continuously changing the color of the background and the letters, *FOCUS* wants to push people not to be distracted by the external factors while keep focusing on the content itself. If users are tired of the flashing color, they can press the button in the popup window, which will turn the background and the letters into red. Even though it's still hard to read, users should also pay more attention and take a closer look at the content.
